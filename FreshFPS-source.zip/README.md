# Fresh FPS (best effort, untested)

Client-only Fabric mod. Requires Fabric API. Does not add rendering code,
so it does not interfere with Sodium. It nudges the render distance option
up when FPS has headroom and back down when FPS sags below the target.

Target: 230 FPS. Ceiling: min(200, 12 x max heap GB), at least 32.

Build:
1. Install JDK 21 and run `./gradlew build`.
2. Put build/libs/freshfps-1.0.0.jar in mods/ next to Fabric API.

Things that may need adjusting for your version:
- gradle.properties: minecraft_version, yarn_mappings, fabric_version.
- ValidatingIntRangeMixin: the injected method signature depends on the mappings.
- Singleplayer: the integrated server may only pick up a new distance after you rejoin.
- Constants TARGET_FPS / MAX_DISTANCE are in FreshFpsMod.java.

No guarantee: 200 chunks is very heavy on memory and CPU.
