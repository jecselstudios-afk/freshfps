package com.freshfps;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;

public class FreshFpsMod implements ClientModInitializer {
    public static final String MOD_ID = "freshfps";

    /** FPS the scaler tries to hold. */
    private static final int TARGET_FPS = 230;
    /** Hard cap for render distance. */
    private static final int MAX_DISTANCE = 200;

    private static DistanceController controller;
    private static int tickCounter = 0;
    private static boolean wasInWorld = false;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(FreshFpsMod::onTick);
    }

    private static void onTick(MinecraftClient client) {
        boolean inWorld = client.world != null && client.player != null;
        if (!inWorld) {
            wasInWorld = false;
            controller = null;
            tickCounter = 0;
            return;
        }

        if (!wasInWorld || controller == null) {
            // Entering a world: start from the user's current setting.
            int start = client.options.getViewDistance().getValue();
            controller = new DistanceController(TARGET_FPS, ceilingForMemory(), start);
            wasInWorld = true;
            tickCounter = 0;
            return;
        }

        if (++tickCounter < 20) return; // sample once per second
        tickCounter = 0;

        controller.onSecond(client, client.getCurrentFps());
    }

    /** Scale the ceiling with available heap so low-memory machines stay sane. */
    private static int ceilingForMemory() {
        long gb = Runtime.getRuntime().maxMemory() / (1024L * 1024L * 1024L);
        int ceiling = (int) Math.min(MAX_DISTANCE, Math.max(32, gb * 12));
        return ceiling;
    }
}
