package com.freshfps.mixin;

import java.util.Optional;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import net.minecraft.client.option.SimpleOption;

/**
 * Vanilla rejects render distances above 32 when a value is set on the option.
 * This lifts that ceiling so the auto-scaler can go higher. Only the value
 * validation is touched; nothing in the render pipeline changes.
 * NOTE: the method signature may need adjusting for your exact mappings.
 */
@Mixin(SimpleOption.ValidatingIntRange.class)
public abstract class ValidatingIntRangeMixin {
    @Inject(method = "validate", at = @At("HEAD"), cancellable = true)
    private void freshfps$allowUpTo200(Integer value, CallbackInfoReturnable<Optional<Integer>> cir) {
        if (value != null && value >= 2 && value <= 200) {
            cir.setReturnValue(Optional.of(value));
        }
    }
}
