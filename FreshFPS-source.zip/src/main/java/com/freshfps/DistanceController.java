package com.freshfps;

import net.minecraft.client.MinecraftClient;

/**
 * Smoothed FPS feedback loop. Steps render distance down quickly when FPS
 * sags and up slowly when there is headroom. Cooldowns prevent oscillation.
 */
final class DistanceController {
    private static final int MIN_DISTANCE = 8;

    private final int targetFps;
    private final int ceiling;
    private double avgFps = -1;
    private int current;
    private int cooldown = 0;

    DistanceController(int targetFps, int ceiling, int startDistance) {
        this.targetFps = targetFps;
        this.ceiling = ceiling;
        this.current = startDistance;
    }

    int current() {
        return current;
    }

    /** Called once per second with the instantaneous FPS. */
    void onSecond(MinecraftClient client, int fps) {
        avgFps = (avgFps < 0) ? fps : avgFps * 0.7 + fps * 0.3;

        if (cooldown > 0) {
            cooldown--;
            return;
        }

        int next = current;
        if (avgFps < targetFps - 15) {
            int drop = (avgFps < targetFps - 60) ? 6 : 2;
            next = Math.max(MIN_DISTANCE, current - drop);
            cooldown = 3;
        } else if (avgFps > targetFps + 25 && current < ceiling) {
            next = Math.min(ceiling, current + 1);
            cooldown = 5;
        }

        if (next != current) {
            client.options.getViewDistance().setValue(next);
            current = next;
        }
    }
}
